library(testthat)
library(Project)

test_check("Project")
