Fun things in R
================
Iain McLaughlan
10/2/2021

  - [R project - quick setup](#r-project---quick-setup)
  - [Renv - library environments](#renv---library-environments)
  - [Roxygen - documentation](#roxygen---documentation)
  - [Testing](#testing)
      - [Testthat - unit testing](#testthat---unit-testing)
      - [Covr - test coverage](#covr---test-coverage)

# R project - quick setup

``` r
# Create an R project
devtools::create(path = "./<PROJECT NAME>")

# Initialise an R environment
renv::init()

# Set up unit testing
usethis::use_testthat()
```

# Renv - library environments

``` r
# Creating an R environment
renv::init()
# Taking a snapshot of the current dependencies and store in renv.lock.
renv::snapshot()

# Load back to the last snapshot
renv::restore()
```

# Roxygen - documentation

In a working file use Ctrl + Alt + Shift + R to add a Roxygen
documentation template.

``` r
# With roxygen comments on functions within ./R create a manual
devtools::document()
```

# Testing

## Testthat - unit testing

``` r
# Create testing file structure
usethis::use_testthat()

# Create tests for the current working file
usethis::use_test() # Adds a test file in ./tests/testthat/test-<FILE NAME>.R<

# Run all tests
devtools::test()
```

## Covr - test coverage
